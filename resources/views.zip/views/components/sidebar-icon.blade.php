<svg xmlns="http://www.w3.org/2000/svg"
     class="h-5 w-5 flex-shrink-0 text-base-content/60 group-[.active]:text-primary transition-colors"
     fill="none" viewBox="0 0 24 24" stroke="currentColor">
    {{ $slot }}
</svg>
